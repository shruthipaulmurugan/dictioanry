import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
  SafeAreaView,
  Platform,
  StatusBar
} from 'react-native';
import { Header } from 'react-native-elements';
import { RFValue } from "react-native-responsive-fontsize";
import * as Speech from 'expo-speech'

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      word:'',
      definition: ''
    };
  }
  getWord = (word) => {
    var url = 'https://api.dictionaryapi.dev/api/v2/entries/en/' + word
    return fetch(url).then(() => {
      return data.json(),
      console.log(data)
    }).then((response) => {
      var word = response[0].word
      var definition = response[0].meaning[0].definitions[0].definition
      this.setState({
        word:word.trim(), 
        definition:definition.trim(),
      })
    }) 
  }
  speak = () => {
    var thingtosay = this.state.word
    this.state.word === ''?alert('Please enter a word'): Speech.speak(thingtosay)
  }
  render() {
    return(
     
      <View style={styles.container}>
       <SafeAreaView style={styles.droidSafeArea} />
        <Header
        backgroundColor={'#b1d3ee'}
        centerComponent={{
            text: 'Dictionary App',
            style: { color: '#000', fontSize: 20 },
          }}/>
      <Image
        source={require("./assets/dict-removebg-preview.png")}
        style={styles.iconImage}
      ></Image>
      <TextInput
        style={styles.inputBox}
        onChangeText={text => {
        this.setState({ text: text });
        }}
         value={this.state.text}
       />
       <TouchableOpacity
          style={styles.goButton}>
          <Text style={styles.buttonText}>GO</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.speaker}>
          <Image source = {require('./assets/Speaker_Icon.svg.png')} style = {{height:60, width:60, marginLeft: 260}}/>
        </TouchableOpacity> 
      </View>
      
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#aeaac6',
  },
   droidSafeArea: {
    marginTop: Platform.OS === "android" ? StatusBar.currentHeight : RFValue(35)
  },
  iconImage: {
    width: "100%",
    height: "30%",
    resizeMode: "contain"
  },
  inputBox: {
    marginTop: 40,
    width: '80%',
    alignSelf: 'center',
    height: 40,
    textAlign: 'center',
    borderWidth: 3,
    outline: 'none',
  },
  goButton: {
    width: '50%',
    height: 55,
    alignSelf: 'center',
    padding: 10,
    margin: 10,
  },
  buttonText: {
    textAlign: 'center',
    fontSize: 30,
    fontWeight: 'bold',
  },
  speaker: {
    backgroundColor : 'blue', 
    flex : 0, 
    marginLeft : -50, 
    marginTop : -68
  }
})

//https://api.dictionaryapi.dev/media/pronunciations/en/dictionary-uk